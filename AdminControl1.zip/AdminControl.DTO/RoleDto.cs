﻿namespace AdminControl.DTO
{
    public class RoleDto
    {
        public int RoleID { get; set; }
        public string RoleName { get; set; }=string.Empty;
    }
}